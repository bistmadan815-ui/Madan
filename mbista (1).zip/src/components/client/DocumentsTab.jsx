import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { Upload, FileText, X, CheckCircle2, Clock, AlertCircle, Loader2, Eye, MessageSquare, Link2 } from 'lucide-react';

const DOC_TYPES = ['Tax Document', 'Bank Statement', 'Business Record', 'Identity Document', 'Financial Statement', 'Other'];

const STATUS_CONFIG = {
  pending_review:  { label: 'Pending Review',   color: 'text-amber-400 border-amber-400/30 bg-amber-400/5',   icon: Clock,         banner: null },
  reviewed:        { label: 'Reviewed',          color: 'text-blue-400 border-blue-400/30 bg-blue-400/5',    icon: Eye,           banner: null },
  requires_action: { label: 'Action Required',   color: 'text-red-400 border-red-400/30 bg-red-400/5',       icon: AlertCircle,   banner: 'border-red-500/20 bg-red-500/5 text-red-300' },
  approved:        { label: 'Approved',           color: 'text-emerald-400 border-emerald-400/30 bg-emerald-400/5', icon: CheckCircle2, banner: 'border-emerald-500/20 bg-emerald-500/5 text-emerald-300' },
};

export default function DocumentsTab({ client, documents, onRefresh }) {
  const [uploading, setUploading] = useState(false);
  const [form, setForm] = useState({ document_type: '', description: '', link_type: '', task_id: '', invoice_id: '' });
  const [selectedFile, setSelectedFile] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [error, setError] = useState('');
  const [tasks, setTasks] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const fileRef = useRef();

  useEffect(() => {
    if (client?.client_id) {
      base44.entities.ClientTask.filter({ client_id: client.client_id }, '-created_date', 50).then(setTasks);
      base44.entities.Invoice.filter({ client_id: client.client_id }, '-created_date', 50).then(setInvoices);
    }
  }, [client?.client_id]);

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!selectedFile || !form.document_type) { setError('Please select a file and document type.'); return; }
    setUploading(true);
    setError('');
    const { file_url } = await base44.integrations.Core.UploadFile({ file: selectedFile });
    // Resolve linked task/invoice metadata
    const linkedTask = form.link_type === 'task' && form.task_id ? tasks.find(t => t.id === form.task_id) : null;
    const linkedInv = form.link_type === 'invoice' && form.invoice_id ? invoices.find(i => i.id === form.invoice_id) : null;
    await base44.entities.ClientDocument.create({
      client_id: client.client_id,
      client_name: client.full_name,
      client_email: client.email,
      file_name: selectedFile.name,
      file_url,
      document_type: form.document_type,
      description: form.description,
      status: 'pending_review',
      uploaded_by_type: 'client',
      task_id: linkedTask?.id || '',
      task_ref: linkedTask?.task_ref || '',
      invoice_id: linkedInv?.id || '',
      invoice_number: linkedInv?.invoice_number || '',
    });
    // Audit log
    await base44.entities.AuditLog.create({
      actor_email: client.email, actor_name: client.full_name, actor_type: 'client',
      action: 'uploaded_document', entity_type: 'ClientDocument', entity_id: '',
      details: `Uploaded: ${selectedFile.name}${linkedTask ? ' linked to task ' + linkedTask.task_ref : ''}${linkedInv ? ' linked to invoice ' + linkedInv.invoice_number : ''}`,
    });
    setUploading(false);
    setSelectedFile(null);
    setForm({ document_type: '', description: '', link_type: '', task_id: '', invoice_id: '' });
    setShowForm(false);
    onRefresh();
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-display text-2xl text-chalk font-light">Documents</h2>
          <p className="font-body text-xs text-chalk/35 mt-1">Securely upload your tax documents, bank statements, and business records.</p>
        </div>
        <button onClick={() => setShowForm(v => !v)}
          className="flex items-center gap-2 font-body text-sm px-5 py-2.5 border border-saffron text-saffron hover:bg-saffron hover:text-background transition-all duration-300 min-h-[44px]">
          <Upload className="w-4 h-4" /> Upload Document
        </button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
            className="border border-border p-6 mb-8 max-w-xl relative">
            <div className="absolute top-0 left-0 right-0 h-px bg-saffron" />
            <div className="flex items-center justify-between mb-4">
              <p className="font-body text-xs tracking-widest uppercase text-saffron">Upload New Document</p>
              <button onClick={() => setShowForm(false)} className="text-chalk/30 hover:text-chalk"><X className="w-4 h-4" /></button>
            </div>
            <form onSubmit={handleUpload} className="space-y-4">
              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2">Document Type <span className="text-saffron">*</span></label>
                <select value={form.document_type} onChange={e => setForm(p => ({ ...p, document_type: e.target.value }))}
                  className="w-full bg-transparent border-b border-basalt/30 py-3 font-body text-sm text-chalk focus:border-saffron focus:outline-none appearance-none">
                  <option value="" className="bg-background text-chalk/40">Select type</option>
                  {DOC_TYPES.map(t => <option key={t} value={t} className="bg-background text-chalk">{t}</option>)}
                </select>
              </div>
              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2">Description</label>
                <input type="text" value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                  placeholder="Brief description of the document..."
                  className="w-full bg-transparent border-b border-basalt/30 py-3 font-body text-sm text-chalk placeholder:text-chalk/20 focus:border-saffron focus:outline-none" />
              </div>

              {/* Linking */}
              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2"><Link2 className="inline w-3 h-3 mr-1" />Link To (optional)</label>
                <select value={form.link_type} onChange={e => setForm(p => ({ ...p, link_type: e.target.value, task_id: '', invoice_id: '' }))}
                  className="w-full bg-transparent border-b border-basalt/30 py-2 font-body text-sm text-chalk focus:border-saffron focus:outline-none appearance-none mb-2">
                  <option value="" className="bg-background">No link</option>
                  <option value="task" className="bg-background">Link to a Task</option>
                  <option value="invoice" className="bg-background">Link to an Invoice</option>
                </select>
                {form.link_type === 'task' && tasks.length > 0 && (
                  <select value={form.task_id} onChange={e => setForm(p => ({ ...p, task_id: e.target.value }))}
                    className="w-full bg-transparent border-b border-basalt/30 py-2 font-body text-sm text-chalk focus:border-saffron focus:outline-none appearance-none">
                    <option value="" className="bg-background">— Select Task —</option>
                    {tasks.map(t => <option key={t.id} value={t.id} className="bg-background">{t.task_ref ? `[${t.task_ref}] ` : ''}{t.title}</option>)}
                  </select>
                )}
                {form.link_type === 'invoice' && invoices.length > 0 && (
                  <select value={form.invoice_id} onChange={e => setForm(p => ({ ...p, invoice_id: e.target.value }))}
                    className="w-full bg-transparent border-b border-basalt/30 py-2 font-body text-sm text-chalk focus:border-saffron focus:outline-none appearance-none">
                    <option value="" className="bg-background">— Select Invoice —</option>
                    {invoices.map(i => <option key={i.id} value={i.id} className="bg-background">{i.invoice_number} — {i.service}</option>)}
                  </select>
                )}
              </div>

              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2">File <span className="text-saffron">*</span></label>
                <div
                  onClick={() => fileRef.current?.click()}
                  className="border border-dashed border-basalt/30 hover:border-saffron/50 p-6 text-center cursor-pointer transition-colors">
                  {selectedFile ? (
                    <div className="flex items-center justify-center gap-2">
                      <FileText className="w-5 h-5 text-saffron" />
                      <span className="font-body text-sm text-chalk/70">{selectedFile.name}</span>
                      <button type="button" onClick={e => { e.stopPropagation(); setSelectedFile(null); }} className="text-chalk/30 hover:text-red-400 ml-2">
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-chalk/20 mx-auto mb-2" />
                      <p className="font-body text-xs text-chalk/30">Click to select a file</p>
                      <p className="font-body text-[10px] text-chalk/20 mt-1">PDF, JPG, PNG, XLSX, DOC supported</p>
                    </>
                  )}
                </div>
                <input ref={fileRef} type="file" className="hidden" accept=".pdf,.jpg,.jpeg,.png,.xlsx,.xls,.doc,.docx"
                  onChange={e => setSelectedFile(e.target.files[0] || null)} />
              </div>
              {error && <p className="font-body text-xs text-red-400">{error}</p>}
              <div className="flex gap-3">
                <button type="submit" disabled={uploading}
                  className="flex items-center gap-2 font-body text-xs px-5 py-2.5 bg-saffron text-background uppercase tracking-wider hover:bg-saffron/90 disabled:opacity-50 transition-all min-h-[44px]">
                  {uploading ? <><Loader2 className="w-4 h-4 animate-spin" /> Uploading...</> : <><Upload className="w-4 h-4" /> Upload</>}
                </button>
                <button type="button" onClick={() => setShowForm(false)}
                  className="font-body text-xs px-5 py-2.5 border border-basalt/30 text-chalk/40 uppercase tracking-wider hover:text-chalk transition-all min-h-[44px]">
                  Cancel
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {documents.length === 0 ? (
        <div className="text-center py-16 border border-dashed border-basalt/20">
          <FileText className="w-10 h-10 text-chalk/15 mx-auto mb-3" />
          <p className="font-display text-xl text-chalk/20 font-light mb-2">No Documents Uploaded</p>
          <p className="font-body text-sm text-chalk/20">Upload your documents securely for our team to review.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {documents.map((doc, i) => {
            const sc = STATUS_CONFIG[doc.status] || STATUS_CONFIG.pending_review;
            const StatusIcon = sc.icon;
            return (
              <motion.div key={doc.id} initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: i * 0.04 }}
                className="border border-border p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-start gap-4 flex-1">
                  <div className="w-10 h-10 border border-basalt/30 flex items-center justify-center flex-shrink-0">
                    <FileText className="w-5 h-5 text-chalk/40" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-body text-sm text-chalk truncate">{doc.file_name}</p>
                    <div className="flex items-center gap-3 mt-1 flex-wrap">
                      <span className={`flex items-center gap-1 font-body text-[10px] tracking-widest uppercase px-2 py-0.5 border ${sc.color}`}>
                        <StatusIcon className="w-3 h-3" />{sc.label}
                      </span>
                      <span className="font-body text-xs text-chalk/30">{doc.document_type}</span>
                      <span className="font-body text-xs text-chalk/20">
                        {new Date(doc.created_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </span>
                    </div>
                    {doc.description && <p className="font-body text-xs text-chalk/30 mt-1">{doc.description}</p>}
                    <div className="flex items-center gap-2 mt-1.5 flex-wrap">
                      {doc.task_ref && (
                        <span className="font-body text-[10px] text-saffron/70 border border-saffron/20 bg-saffron/5 px-2 py-0.5">Task: {doc.task_ref}</span>
                      )}
                      {doc.invoice_number && (
                        <span className="font-body text-[10px] text-blue-400/70 border border-blue-400/20 bg-blue-400/5 px-2 py-0.5">Invoice: {doc.invoice_number}</span>
                      )}
                    </div>
                    {doc.staff_notes && (() => {
                      const sc = STATUS_CONFIG[doc.status];
                      return (
                        <div className={`mt-3 p-3 border rounded flex items-start gap-2 ${sc?.banner || 'border-basalt/20 bg-basalt/5 text-chalk/50'}`}>
                          <MessageSquare className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="font-body text-[10px] tracking-widest uppercase mb-0.5 opacity-70">Staff Response</p>
                            <p className="font-body text-xs leading-relaxed">{doc.staff_notes}</p>
                          </div>
                        </div>
                      );
                    })()}
                  </div>
                </div>
                <a href={doc.file_url} target="_blank" rel="noopener noreferrer"
                  className="flex items-center gap-2 font-body text-xs px-4 py-2.5 border border-basalt/30 text-chalk/50 hover:border-saffron hover:text-saffron transition-all min-h-[44px] flex-shrink-0">
                  <Eye className="w-4 h-4" /> View
                </a>
              </motion.div>
            );
          })}
        </div>
      )}
    </div>
  );
}