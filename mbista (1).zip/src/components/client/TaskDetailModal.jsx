import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { X, Send, Loader2, Clock, User, Tag, Calendar, FileText, Paperclip } from 'lucide-react';
import RelatedItemsPanel from '@/components/shared/RelatedItemsPanel';

const STATUS_CONFIG = {
  draft:              { label: 'Draft',          color: 'text-chalk/40 border-basalt/30 bg-basalt/5' },
  assigned:           { label: 'Assigned',       color: 'text-blue-300 border-blue-300/30 bg-blue-300/5' },
  in_progress:        { label: 'In Progress',    color: 'text-blue-400 border-blue-400/30 bg-blue-400/5' },
  awaiting_documents: { label: 'Awaiting Docs',  color: 'text-amber-400 border-amber-400/30 bg-amber-400/5' },
  pending_review:     { label: 'Pending Review', color: 'text-violet-300 border-violet-300/30 bg-violet-300/5' },
  review:             { label: 'In Review',      color: 'text-violet-400 border-violet-400/30 bg-violet-400/5' },
  filed:              { label: 'Filed',          color: 'text-saffron border-saffron/30 bg-saffron/5' },
  completed:          { label: 'Completed',      color: 'text-emerald-400 border-emerald-400/30 bg-emerald-400/5' },
  overdue:            { label: 'Overdue',        color: 'text-red-400 border-red-400/30 bg-red-400/5' },
  // legacy
  pending:            { label: 'Pending',        color: 'text-amber-400 border-amber-400/30 bg-amber-400/5' },
};

const PRIORITY_CONFIG = {
  low:      { label: 'Low',      color: 'text-chalk/40', dot: 'bg-chalk/20' },
  medium:   { label: 'Medium',   color: 'text-amber-400', dot: 'bg-amber-400' },
  high:     { label: 'High',     color: 'text-orange-400', dot: 'bg-orange-400' },
  critical: { label: 'Critical', color: 'text-red-400', dot: 'bg-red-400' },
};

const COMMENTER_COLORS = {
  admin:  'border-saffron/30 bg-saffron/5',
  staff:  'border-blue-400/30 bg-blue-400/5',
  client: 'border-emerald-400/30 bg-emerald-400/5',
};

export default function TaskDetailModal({ task, user, userType, onClose }) {
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => { loadComments(); }, []);

  const loadComments = async () => {
    setLoading(true);
    const result = await base44.entities.TaskComment.filter({ task_id: task.id }, 'created_date', 100);
    setComments(result);
    setLoading(false);
  };

  const handleSubmitComment = async (e) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    setSubmitting(true);
    await base44.entities.TaskComment.create({
      task_id: task.id,
      comment_text: newComment,
      commenter_name: user,
      commenter_type: userType,
    });
    setNewComment('');
    await loadComments();
    setSubmitting(false);
  };

  const sc = STATUS_CONFIG[task.status] || STATUS_CONFIG.pending;
  const pc = PRIORITY_CONFIG[task.priority];

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-md" onClick={onClose}>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
        className="relative bg-background border border-border w-full max-w-2xl max-h-[88vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="absolute top-0 left-0 right-0 h-px bg-saffron" />

        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-border gap-4">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              <span className={`font-body text-[10px] tracking-widest uppercase px-2 py-0.5 border ${sc.color}`}>{sc.label}</span>
              {pc && (
                <span className="flex items-center gap-1 font-body text-[10px]">
                  <span className={`w-1.5 h-1.5 rounded-full ${pc.dot}`} />
                  <span className={pc.color}>{pc.label}</span>
                </span>
              )}
              {task.task_ref && <span className="font-body text-[10px] text-chalk/25 font-mono">{task.task_ref}</span>}
            </div>
            <h2 className="font-display text-2xl text-chalk font-light leading-tight">{task.title}</h2>
            {task.description && <p className="font-body text-sm text-chalk/60 mt-1">{task.description}</p>}
          </div>
          <button onClick={onClose} className="text-chalk/30 hover:text-chalk flex-shrink-0 mt-1"><X className="w-5 h-5" /></button>
        </div>

        {/* Meta grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 p-6 border-b border-border">
          {[
            { icon: User,     label: 'Assigned To',   value: task.assigned_to || '—' },
            { icon: Tag,      label: 'Service',        value: task.service || '—' },
            { icon: Calendar, label: 'Start Date',     value: task.start_date || '—' },
            { icon: Clock,    label: 'Due Date',       value: task.due_date || '—' },
            { icon: FileText, label: 'Client',         value: task.client_name || '—' },
            { icon: Tag,      label: 'Client ID',      value: task.client_id || '—' },
          ].map(({ icon: Icon, label, value }) => (
            <div key={label}>
              <p className="font-body text-[10px] uppercase tracking-widest text-chalk/25 mb-0.5 flex items-center gap-1">
                <Icon className="w-3 h-3" /> {label}
              </p>
              <p className="font-body text-xs text-chalk/70">{value}</p>
            </div>
          ))}
        </div>

        {/* Progress notes */}
        {task.progress_notes && (
          <div className="p-6 border-b border-border">
            <p className="font-body text-[10px] uppercase tracking-widest text-chalk/25 mb-2">Progress Notes</p>
            <p className="font-body text-sm text-chalk/60 whitespace-pre-wrap border-l-2 border-saffron/30 pl-3">{task.progress_notes}</p>
          </div>
        )}

        {/* Related Items */}
        {(task.client_id || task.id) && (
          <div className="px-6">
            <RelatedItemsPanel taskId={task.id} clientId={task.client_id} />
          </div>
        )}

        {/* Comments */}
        <div className="p-6">
          <h3 className="font-display text-lg text-chalk font-light mb-5">Discussion</h3>

          <div className="space-y-3 mb-6 max-h-72 overflow-y-auto">
            {loading ? (
              <div className="flex justify-center py-8">
                <div className="w-4 h-4 border-2 border-saffron border-t-transparent rounded-full animate-spin" />
              </div>
            ) : comments.length === 0 ? (
              <p className="font-body text-xs text-chalk/30 text-center py-8">No comments yet. Start the discussion.</p>
            ) : (
              comments.map(comment => (
                <div key={comment.id} className={`border p-4 ${COMMENTER_COLORS[comment.commenter_type] || 'border-basalt/30 bg-basalt/5'}`}>
                  <div className="flex items-start justify-between mb-1.5">
                    <div>
                      <span className="font-body text-xs font-semibold text-chalk">{comment.commenter_name}</span>
                      <span className={`ml-2 font-body text-[10px] uppercase tracking-widest ${
                        comment.commenter_type === 'admin' ? 'text-saffron' :
                        comment.commenter_type === 'staff' ? 'text-blue-400' : 'text-emerald-400'
                      }`}>{comment.commenter_type}</span>
                    </div>
                    <span className="font-body text-[10px] text-chalk/25">
                      {new Date(comment.created_date).toLocaleDateString('en-GB')} {new Date(comment.created_date).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                  <p className="font-body text-sm text-chalk/70 leading-relaxed">{comment.comment_text}</p>
                </div>
              ))
            )}
          </div>

          <form onSubmit={handleSubmitComment} className="border-t border-basalt/20 pt-4 space-y-3">
            <textarea rows={3} value={newComment} onChange={e => setNewComment(e.target.value)}
              placeholder="Add a comment or update..."
              className="w-full bg-transparent border-b border-basalt/30 py-2 font-body text-sm text-chalk placeholder:text-chalk/20 focus:border-saffron focus:outline-none resize-none" />
            <button type="submit" disabled={submitting || !newComment.trim()}
              className="flex items-center justify-center gap-2 font-body text-xs px-5 py-2.5 bg-saffron text-background uppercase tracking-wider hover:bg-saffron/90 disabled:opacity-50 transition-all min-h-[40px]">
              {submitting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <><Send className="w-3.5 h-3.5" /> Post Comment</>}
            </button>
          </form>
        </div>
      </motion.div>
    </motion.div>
  );
}