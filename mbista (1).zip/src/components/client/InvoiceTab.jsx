import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { FileText, Eye, CheckCircle2, Clock, AlertCircle, XCircle, CreditCard,
  AlertOctagon, ShieldQuestion, Loader2, Check, CalendarClock, Info } from 'lucide-react';
import VATInvoicePreview from '@/components/admin/VATInvoicePreview';

const STATUS_CONFIG = {
  unpaid:            { label: 'Unpaid',          color: 'text-amber-400 border-amber-400/30 bg-amber-400/5',      icon: Clock },
  paid:              { label: 'Paid',            color: 'text-emerald-400 border-emerald-400/30 bg-emerald-400/5', icon: CheckCircle2 },
  overdue:           { label: 'Overdue',         color: 'text-red-400 border-red-400/30 bg-red-400/5',            icon: AlertCircle },
  cancelled:         { label: 'Cancelled',       color: 'text-basalt border-basalt/30 bg-basalt/5',               icon: XCircle },
  payment_requested: { label: 'Payment Due',     color: 'text-blue-400 border-blue-400/30 bg-blue-400/5',         icon: Clock },
};

function daysUntil(dateStr) {
  if (!dateStr) return null;
  return Math.ceil((new Date(dateStr) - new Date()) / (1000 * 60 * 60 * 24));
}

function formatNPR(n) { return 'NPR ' + Number(n).toLocaleString('en-IN'); }

// ── Credit Extension Modal ─────────────────────────────────────────
function CreditExtensionModal({ inv, client, onClose, onRefresh }) {
  const [reason, setReason] = useState('');
  const [days, setDays] = useState('');
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!reason.trim() || !days || parseInt(days) <= 0) return;
    setSaving(true);
    await base44.entities.Invoice.update(inv.id, {
      credit_extension_requested: true,
      credit_extension_reason: reason,
      credit_extension_days: parseInt(days),
      credit_extension_status: 'pending',
    });
    const admins = await base44.entities.Admin.list('-created_date', 5);
    for (const admin of admins) {
      await base44.entities.Notification.create({
        admin_id: admin.id, type: 'staff_alert',
        title: 'Credit Extension Request',
        message: `${client?.full_name || 'Client'} requests ${days} extra days for invoice ${inv.invoice_number}. Reason: ${reason}`,
        reference_id: inv.id, reference_type: 'Invoice', priority: 'high',
      });
    }
    await base44.entities.AuditLog.create({
      actor_email: client?.email || '', actor_name: client?.full_name || '', actor_type: 'client',
      action: 'credit_extension_requested', entity_type: 'Invoice', entity_id: inv.id,
      details: `Extension: ${days} days — ${reason}`,
    });
    setSaving(false);
    setDone(true);
    if (onRefresh) setTimeout(onRefresh, 500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/80 backdrop-blur-md" onClick={onClose}>
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
        className="relative bg-background border border-border w-full max-w-md p-8" onClick={e => e.stopPropagation()}>
        <div className="absolute top-0 left-0 right-0 h-px bg-saffron" />
        {done ? (
          <div className="text-center py-4">
            <div className="w-12 h-12 border-2 border-saffron flex items-center justify-center mx-auto mb-4">
              <Check className="w-6 h-6 text-saffron" />
            </div>
            <h3 className="font-display text-xl text-chalk font-light mb-2">Request Submitted</h3>
            <p className="font-body text-sm text-chalk/40">Our team will review your credit extension request.</p>
            <button onClick={onClose} className="mt-6 font-body text-xs px-6 py-2.5 border border-basalt/30 text-chalk/50 hover:border-saffron hover:text-saffron transition-all min-h-[44px]">Close</button>
          </div>
        ) : (
          <>
            <div className="flex items-start justify-between mb-5">
              <div>
                <p className="font-body text-xs tracking-widest uppercase text-saffron mb-1">Credit Extension Request</p>
                <h3 className="font-display text-xl text-chalk font-light">{inv.invoice_number}</h3>
              </div>
              <button onClick={onClose} className="text-chalk/30 hover:text-chalk"><XCircle className="w-5 h-5" /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2">Additional Days Requested <span className="text-saffron">*</span></label>
                <input type="number" min="1" max="90" value={days} onChange={e => setDays(e.target.value)} placeholder="e.g. 15"
                  className="w-full bg-transparent border-b border-basalt/30 py-2 font-body text-sm text-chalk placeholder:text-chalk/20 focus:border-saffron focus:outline-none" />
              </div>
              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2">Reason <span className="text-saffron">*</span></label>
                <textarea rows={3} value={reason} onChange={e => setReason(e.target.value)}
                  placeholder="Briefly explain why you need an extension..."
                  className="w-full bg-transparent border-b border-basalt/30 py-2 font-body text-sm text-chalk placeholder:text-chalk/20 focus:border-saffron focus:outline-none resize-none" />
              </div>
              <div className="flex gap-3 pt-1">
                <button type="submit" disabled={saving || !reason.trim() || !days || parseInt(days) <= 0}
                  className="flex-1 flex items-center justify-center gap-2 font-body text-sm py-3 bg-saffron text-background font-medium tracking-wider uppercase hover:bg-saffron/90 disabled:opacity-40 min-h-[44px]">
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Submit Request'}
                </button>
                <button type="button" onClick={onClose}
                  className="font-body text-xs px-5 py-3 border border-basalt/30 text-chalk/40 uppercase tracking-wider min-h-[44px]">Cancel</button>
              </div>
            </form>
          </>
        )}
      </motion.div>
    </div>
  );
}

// ── Main InvoiceTab ────────────────────────────────────────────────
export default function InvoiceTab({ client, invoices, onMarkPaid, onMakePayment, onRefresh }) {
  const [waiverLoading, setWaiverLoading] = useState('');
  const [viewing, setViewing] = useState(null);
  const [deferringId, setDeferringId] = useState('');
  const [extensionInv, setExtensionInv] = useState(null);

  const handleDefer = async (inv) => {
    setDeferringId(inv.id);
    await base44.entities.Invoice.update(inv.id, {
      notes: (inv.notes ? inv.notes + '\n' : '') + 'Client deferred payment on ' + new Date().toLocaleDateString('en-GB'),
    });
    setDeferringId('');
    if (onRefresh) onRefresh();
  };

  const requestWaiver = async (inv) => {
    setWaiverLoading(inv.id);
    await base44.entities.Invoice.update(inv.id, { waiver_requested: true, waiver_status: 'pending' });
    setWaiverLoading('');
    if (onRefresh) onRefresh();
  };

  if (invoices.length === 0) {
    return (
      <div className="text-center py-16 border border-dashed border-basalt/20">
        <FileText className="w-10 h-10 text-chalk/15 mx-auto mb-3" />
        <p className="font-display text-xl text-chalk/20 font-light mb-2">No Invoices Yet</p>
        <p className="font-body text-sm text-chalk/20">Invoices for completed services will appear here.</p>
      </div>
    );
  }

  const totalDue = invoices.filter(i => i.status !== 'paid' && i.status !== 'cancelled')
    .reduce((s, i) => s + (Number(i.amount) * (1 + (i.tax_rate || 13) / 100)), 0);
  const totalPaid = invoices.filter(i => i.status === 'paid')
    .reduce((s, i) => s + (Number(i.amount) * (1 + (i.tax_rate || 13) / 100)), 0);

  return (
    <div>
      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-8">
        {[
          { label: 'Total Invoices', value: invoices.length, color: 'text-chalk' },
          { label: 'Amount Due', value: formatNPR(Math.round(totalDue)), color: 'text-amber-400' },
          { label: 'Total Paid', value: formatNPR(Math.round(totalPaid)), color: 'text-emerald-400' },
        ].map(s => (
          <div key={s.label} className="border border-border p-5">
            <p className="font-body text-xs text-chalk/30 tracking-widest uppercase mb-1">{s.label}</p>
            <p className={`font-display text-xl font-light ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      <div className="space-y-4">
        {invoices.map((inv, i) => {
          const sc = STATUS_CONFIG[inv.status] || STATUS_CONFIG.unpaid;
          const StatusIcon = sc.icon;
          const taxAmt = (Number(inv.amount) * (inv.tax_rate || 13)) / 100;
          const total = Number(inv.amount) + taxAmt;
          const isPaid = inv.status === 'paid';
          const isCancelled = inv.status === 'cancelled';
          const canPay = !isPaid && !isCancelled;
          const canExtend = (inv.status === 'payment_requested' || inv.status === 'overdue') && !inv.credit_extension_requested;
          const alreadyExtended = inv.credit_extension_requested;

          return (
            <motion.div key={inv.id} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}
              className="border border-border p-6">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
                {/* Left: info */}
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3 flex-wrap">
                    <span className={`flex items-center gap-1.5 font-body text-[10px] tracking-widest uppercase px-2.5 py-1 border ${sc.color}`}>
                      <StatusIcon className="w-3 h-3" />{sc.label}
                    </span>
                    <span className="font-body text-xs text-chalk/30 font-mono">{inv.invoice_number}</span>
                  </div>

                  <p className="font-display text-lg text-chalk font-light">{inv.service}</p>
                  {inv.description && <p className="font-body text-xs text-chalk/35 mt-1">{inv.description}</p>}

                  <div className="flex items-baseline gap-3 mt-2">
                    {inv.discount_status === 'approved' && Number(inv.discount_amount) > 0 ? (
                      <>
                        <span className="font-display text-base text-chalk/35 font-light line-through">{formatNPR(Math.round(total))}</span>
                        <span className="font-display text-2xl text-emerald-400 font-light">{formatNPR(Math.round(total - Number(inv.discount_amount)))}</span>
                      </>
                    ) : (
                      <span className="font-display text-2xl text-chalk font-light">{formatNPR(Math.round(total))}</span>
                    )}
                    <span className="font-body text-xs text-chalk/30">incl. {inv.tax_rate || 13}% VAT</span>
                  </div>
                  {/* Discount status badges */}
                  {inv.discount_status === 'pending' && (
                    <div className="mt-2 inline-flex items-center gap-1.5 font-body text-[10px] uppercase tracking-widest px-3 py-1.5 border text-amber-400 border-amber-400/30 bg-amber-400/5">
                      Discount Pending Approval
                    </div>
                  )}
                  {inv.discount_status === 'approved' && Number(inv.discount_amount) > 0 && (
                    <div className="mt-2 inline-flex items-center gap-1.5 font-body text-[10px] uppercase tracking-widest px-3 py-1.5 border text-emerald-400 border-emerald-400/30 bg-emerald-400/5">
                      Discount Applied — NPR {Number(inv.discount_amount).toLocaleString('en-IN')}
                    </div>
                  )}
                  {inv.discount_status === 'rejected' && (
                    <div className="mt-2 inline-flex items-center gap-1.5 font-body text-[10px] uppercase tracking-widest px-3 py-1.5 border text-red-400 border-red-400/30 bg-red-400/5">
                      Discount Request Rejected
                    </div>
                  )}

                  {/* Invoice date */}
                  {inv.due_date && inv.status !== 'payment_requested' && (
                    <p className="font-body text-xs text-chalk/30 mt-1 flex items-center gap-1">
                      <Clock className="w-3 h-3" /> Invoice Date: {inv.due_date}
                    </p>
                  )}

                  {/* Payment due date countdown */}
                  {inv.status === 'payment_requested' && inv.payment_due_date && (() => {
                    const d = daysUntil(inv.payment_due_date);
                    return (
                      <div className={`mt-2 inline-flex items-center gap-2 font-body text-xs px-3 py-1.5 border ${
                        d < 0 ? 'text-red-400 border-red-400/30 bg-red-400/5' : 'text-blue-400 border-blue-400/30 bg-blue-400/5'
                      }`}>
                        <Clock className="w-3 h-3" />
                        Payment due: <strong>{inv.payment_due_date}</strong>
                        {d >= 0 ? ` · ${d} day${d !== 1 ? 's' : ''} remaining` : ` · ${Math.abs(d)} day${Math.abs(d) !== 1 ? 's' : ''} overdue`}
                      </div>
                    );
                  })()}

                  {isPaid && inv.paid_date && (
                    <p className="font-body text-xs text-emerald-400/70 mt-1 flex items-center gap-1">
                      <CheckCircle2 className="w-3 h-3" /> Paid on {inv.paid_date}
                      {inv.payment_method_used && ` via ${inv.payment_method_used.replace('_', ' ')}`}
                    </p>
                  )}

                  {/* Credit & payment info panel */}
                  {(inv.credit_period_days || inv.payment_due_date || inv.payment_reference || inv.credit_extension_requested) && (
                    <div className="mt-3 border border-basalt/15 bg-muted/20 p-3 grid grid-cols-2 sm:grid-cols-3 gap-3">
                      {inv.credit_period_days && (
                        <div><p className="font-body text-[10px] uppercase tracking-widest text-chalk/25">Credit Period</p>
                          <p className="font-body text-xs text-chalk/60 mt-0.5">{inv.credit_period_days} days</p></div>
                      )}
                      {inv.payment_request_date && (
                        <div><p className="font-body text-[10px] uppercase tracking-widest text-chalk/25">Requested On</p>
                          <p className="font-body text-xs text-chalk/60 mt-0.5">{inv.payment_request_date}</p></div>
                      )}
                      {inv.payment_reference && (
                        <div><p className="font-body text-[10px] uppercase tracking-widest text-chalk/25">Reference</p>
                          <p className="font-body text-xs text-chalk/60 mt-0.5 font-mono">{inv.payment_reference}</p></div>
                      )}
                      {alreadyExtended && (
                        <div><p className="font-body text-[10px] uppercase tracking-widest text-chalk/25">Extension</p>
                          <p className={`font-body text-xs mt-0.5 ${
                            inv.credit_extension_status === 'approved' ? 'text-emerald-400' :
                            inv.credit_extension_status === 'rejected' ? 'text-red-400' : 'text-amber-400'
                          }`}>{inv.credit_extension_days}d — {inv.credit_extension_status}</p></div>
                      )}
                    </div>
                  )}
                </div>

                {/* Right: actions */}
                <div className="flex flex-col gap-2 flex-shrink-0 min-w-[145px]">
                  <button onClick={() => setViewing(inv)}
                    className="flex items-center gap-2 font-body text-xs px-4 py-2.5 border border-basalt/30 text-chalk/50 hover:border-saffron hover:text-saffron transition-all min-h-[44px]">
                    <Eye className="w-4 h-4" /> View Invoice
                  </button>

                  {canPay && (
                    <button onClick={() => onMakePayment && onMakePayment(inv)}
                      className="flex items-center gap-2 font-body text-xs px-4 py-2.5 bg-saffron text-background font-medium hover:bg-saffron/90 transition-all min-h-[44px]">
                      <CreditCard className="w-4 h-4" /> Make Payment
                    </button>
                  )}

                  {/* Credit extension */}
                  {(inv.status === 'payment_requested' || inv.status === 'overdue') && (
                    alreadyExtended ? (
                      <div className="flex items-center gap-2 font-body text-[10px] text-chalk/30 border border-basalt/20 px-3 py-2.5 min-h-[44px]">
                        <Info className="w-3.5 h-3.5 flex-shrink-0" />
                        {inv.credit_extension_status === 'approved' ? 'Extension Approved' :
                          inv.credit_extension_status === 'rejected' ? 'Extension Rejected' : 'Extension Pending'}
                      </div>
                    ) : (
                      <button onClick={() => setExtensionInv(inv)}
                        className="flex items-center gap-2 font-body text-xs px-4 py-2.5 border border-amber-400/30 text-amber-400 hover:bg-amber-400/5 transition-all min-h-[44px]">
                        <CalendarClock className="w-4 h-4" /> Credit Extension
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Late Fine Section — preserved exactly */}
              {inv.late_fine_applied && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
                  className="mt-4 border border-red-500/20 bg-red-500/5 p-4 space-y-3">
                  <div className="flex items-start gap-2">
                    <AlertOctagon className="w-4 h-4 text-red-400 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="font-body text-sm text-red-300 font-medium">Late Payment Fine Applied</p>
                      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-2">
                        {[
                          { label: 'Days Overdue',   value: `${inv.late_fine_days || '?'} days` },
                          { label: 'Fine Amount',    value: `NPR ${(inv.late_fine_amount || 0).toLocaleString('en-IN')}` },
                          { label: 'Original Total', value: `NPR ${Math.round(Number(inv.amount) * (1 + (inv.tax_rate || 13) / 100)).toLocaleString('en-IN')}` },
                          { label: 'New Total Due',  value: `NPR ${(Math.round(Number(inv.amount) * (1 + (inv.tax_rate || 13) / 100)) + (inv.late_fine_amount || 0)).toLocaleString('en-IN')}` },
                        ].map(s => (
                          <div key={s.label}>
                            <p className="font-body text-[10px] uppercase tracking-widest text-chalk/25">{s.label}</p>
                            <p className="font-body text-sm text-chalk/70 mt-0.5">{s.value}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                  {!inv.waiver_requested && inv.waiver_status !== 'approved' && inv.waiver_status !== 'denied' && (
                    <button onClick={() => requestWaiver(inv)} disabled={waiverLoading === inv.id}
                      className="flex items-center gap-2 font-body text-xs px-4 py-2 border border-amber-400/40 text-amber-400 hover:bg-amber-400/10 disabled:opacity-50 transition-all min-h-[36px]">
                      {waiverLoading === inv.id ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <ShieldQuestion className="w-3.5 h-3.5" />}
                      Request Fine Waiver
                    </button>
                  )}
                  {inv.waiver_requested && inv.waiver_status === 'pending' && (
                    <span className="inline-flex items-center gap-1.5 font-body text-xs text-amber-400 border border-amber-400/30 bg-amber-400/5 px-3 py-1.5">
                      <ShieldQuestion className="w-3.5 h-3.5" /> Waiver under review by our team
                    </span>
                  )}
                  {inv.waiver_status === 'approved' && (
                    <span className="inline-flex items-center gap-1.5 font-body text-xs text-emerald-400 border border-emerald-400/30 bg-emerald-400/5 px-3 py-1.5">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Fine waiver approved — fine removed
                    </span>
                  )}
                  {inv.waiver_status === 'denied' && (
                    <span className="inline-flex items-center gap-1.5 font-body text-xs text-red-400 border border-red-400/30 bg-red-400/5 px-3 py-1.5">
                      <XCircle className="w-3.5 h-3.5" /> Waiver denied — fine remains applicable
                    </span>
                  )}
                </motion.div>
              )}
            </motion.div>
          );
        })}
      </div>

      <AnimatePresence>
        {viewing && <VATInvoicePreview inv={viewing} onClose={() => setViewing(null)} />}
        {extensionInv && (
          <CreditExtensionModal inv={extensionInv} client={client} onClose={() => setExtensionInv(null)} onRefresh={onRefresh} />
        )}
      </AnimatePresence>
    </div>
  );
}