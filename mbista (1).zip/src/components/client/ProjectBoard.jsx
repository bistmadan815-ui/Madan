import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Clock, FileSearch, CheckCircle2, FolderOpen, CircleDot, AlertCircle } from 'lucide-react';
import TaskDetailModal from './TaskDetailModal';

const PRIORITY_DOT = { low: 'bg-chalk/20', medium: 'bg-amber-400', high: 'bg-orange-400', critical: 'bg-red-400' };

const COLUMNS = [
  { id: 'draft',              label: 'Draft',               icon: Clock,         color: 'text-chalk/40',     border: 'border-basalt/20',    bg: 'bg-basalt/5' },
  { id: 'assigned',           label: 'Assigned',            icon: CircleDot,     color: 'text-blue-300',     border: 'border-blue-300/20',  bg: 'bg-blue-300/5' },
  { id: 'pending',            label: 'Pending',             icon: Clock,         color: 'text-chalk/40',     border: 'border-basalt/20',    bg: 'bg-basalt/5' },
  { id: 'in_progress',        label: 'In Progress',         icon: CircleDot,     color: 'text-blue-400',     border: 'border-blue-400/20',  bg: 'bg-blue-400/5' },
  { id: 'awaiting_documents', label: 'Awaiting Documents',  icon: AlertCircle,   color: 'text-amber-400',    border: 'border-amber-400/20', bg: 'bg-amber-400/5' },
  { id: 'pending_review',     label: 'Pending Review',      icon: FileSearch,    color: 'text-violet-300',   border: 'border-violet-300/20',bg: 'bg-violet-300/5' },
  { id: 'review',             label: 'In Review',           icon: FileSearch,    color: 'text-violet-400',   border: 'border-violet-400/20',bg: 'bg-violet-400/5' },
  { id: 'filed',              label: 'Filed',               icon: FolderOpen,    color: 'text-saffron',      border: 'border-saffron/20',   bg: 'bg-saffron/5' },
  { id: 'overdue',            label: 'Overdue',             icon: AlertCircle,   color: 'text-red-400',      border: 'border-red-400/20',   bg: 'bg-red-400/5' },
  { id: 'completed',          label: 'Completed',           icon: CheckCircle2,  color: 'text-emerald-400',  border: 'border-emerald-400/20',bg: 'bg-emerald-400/5' },
];

function TaskCard({ task, index, onTaskClick }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.04 }}
      onClick={() => onTaskClick(task)}
      className="border border-border bg-background p-3 space-y-1.5 cursor-pointer hover:border-saffron/50 hover:bg-saffron/5 transition-all"
    >
      <div className="flex items-center gap-2 mb-1 flex-wrap">
        {task.priority && <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${PRIORITY_DOT[task.priority] || 'bg-chalk/20'}`} />}
        <p className="font-body text-sm text-chalk leading-snug">{task.title}</p>
      </div>
      {task.service && (
        <p className="font-body text-[10px] tracking-widest uppercase text-saffron/70">{task.service}</p>
      )}
      {task.description && (
        <p className="font-body text-xs text-chalk/35 leading-relaxed">{task.description}</p>
      )}
      <div className="flex items-center gap-3 pt-0.5">
        {task.due_date && (
          <span className="flex items-center gap-1 font-body text-[10px] text-chalk/25">
            <Clock className="w-3 h-3" /> {task.due_date}
          </span>
        )}
        {task.assigned_to && (
          <span className="font-body text-[10px] text-chalk/25 truncate">→ {task.assigned_to}</span>
        )}
      </div>
    </motion.div>
  );
}

export default function ProjectBoard({ tasks, user = 'Client', userType = 'client' }) {
  const [selectedTask, setSelectedTask] = useState(null);

  if (tasks.length === 0) {
    return (
      <div className="text-center py-16 border border-dashed border-basalt/20">
        <CircleDot className="w-10 h-10 text-chalk/15 mx-auto mb-3" />
        <p className="font-display text-xl text-chalk/20 font-light">No Work Items Assigned</p>
        <p className="font-body text-sm text-chalk/20 mt-2">Your project tasks will appear here as work begins.</p>
      </div>
    );
  }

  const byStatus = (colId) => tasks.filter(t => (t.status || 'draft') === colId);
  const completed = tasks.filter(t => t.status === 'completed' || t.status === 'filed').length;
  const progress = Math.round((completed / tasks.length) * 100);

  return (
    <div>
      {/* Progress bar */}
      <div className="mb-8 p-5 border border-border">
        <div className="flex items-center justify-between mb-3">
          <p className="font-body text-xs tracking-widest uppercase text-chalk/35">Overall Progress</p>
          <p className="font-body text-sm text-saffron">{progress}% complete</p>
        </div>
        <div className="w-full h-1.5 bg-basalt/20 rounded-full overflow-hidden">
          <motion.div
            className="h-full bg-saffron rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.8, ease: 'easeOut' }}
          />
        </div>
        <div className="flex items-center gap-6 mt-3">
          {COLUMNS.map(col => {
            const count = byStatus(col.id).length;
            if (!count) return null;
            const Icon = col.icon;
            return (
              <span key={col.id} className={`flex items-center gap-1.5 font-body text-xs ${col.color}`}>
                <Icon className="w-3 h-3" /> {count} {col.label}
              </span>
            );
          })}
        </div>
      </div>

      {/* Kanban board */}
      <div className="overflow-x-auto pb-4">
        <div className="flex gap-4 min-w-max">
          {COLUMNS.map(col => {
            const colTasks = byStatus(col.id);
            const Icon = col.icon;
            return (
              <div key={col.id} className={`w-60 flex-shrink-0 border ${col.border} ${col.bg} p-3`}>
                <div className={`flex items-center gap-2 mb-3 pb-2 border-b ${col.border}`}>
                  <Icon className={`w-3.5 h-3.5 ${col.color}`} />
                  <p className={`font-body text-xs tracking-widest uppercase ${col.color}`}>{col.label}</p>
                  <span className={`ml-auto font-body text-xs font-medium ${col.color}`}>{colTasks.length}</span>
                </div>
                <div className="space-y-2">
                  {colTasks.length === 0 ? (
                    <p className="font-body text-[10px] text-chalk/15 text-center py-4">—</p>
                  ) : (
                    colTasks.map((task, i) => <TaskCard key={task.id} task={task} index={i} onTaskClick={setSelectedTask} />)
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <AnimatePresence>
        {selectedTask && (
          <TaskDetailModal task={selectedTask} user={user} userType={userType} onClose={() => setSelectedTask(null)} />
        )}
      </AnimatePresence>
    </div>
  );
}