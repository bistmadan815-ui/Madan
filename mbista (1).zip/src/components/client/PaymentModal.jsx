import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import { X, Copy, Check, Loader2, CreditCard, Banknote, MoreHorizontal, Clock, CheckCircle2 } from 'lucide-react';

const BANK_DETAILS = {
  bank: 'Nabil Bank Limited',
  branch: 'Kathmandu, New Road Branch',
  account_name: 'M. Bista & Associates Pvt. Ltd.',
  account_no: '0123456789012345',
  swift: 'NARBNPKA',
};

const METHODS = [
  { id: 'cash',          label: 'Cash',              icon: Banknote,      color: 'border-emerald-400/40 text-emerald-400',  desc: 'Pay in person at our office' },
  { id: 'bank_transfer', label: 'Bank Transfer',     icon: CreditCard,    color: 'border-blue-400/40 text-blue-400',        desc: 'Direct bank transfer / RTGS' },
  { id: 'esewa',         label: 'eSewa',             icon: null,          color: 'border-green-400/40 text-green-400',      desc: 'eSewa ID: 9841XXXXXX', emoji: '🟢' },
  { id: 'khalti',        label: 'Khalti',            icon: null,          color: 'border-violet-400/40 text-violet-400',    desc: 'Khalti ID: 9841XXXXXX', emoji: '🟣' },
  { id: 'other',         label: 'Other',             icon: MoreHorizontal, color: 'border-basalt/40 text-chalk/50',         desc: 'Other payment arrangement' },
];

export default function PaymentModal({ invoice, onClose, onRefresh, client }) {
  const [step, setStep] = useState('method');   // method | confirm | done
  const [method, setMethod] = useState('');
  const [reference, setReference] = useState('');
  const [copied, setCopied] = useState('');
  const [saving, setSaving] = useState(false);
  const [action, setAction] = useState('');     // 'pay_now' | 'pay_later'

  const copy = (val, key) => {
    navigator.clipboard.writeText(val);
    setCopied(key);
    setTimeout(() => setCopied(''), 2000);
  };

  const taxable = Number(invoice?.amount || 0);
  const vatAmt = (taxable * (invoice?.tax_rate || 13)) / 100;
  const total = taxable + vatAmt;
  const fmt = n => 'NPR ' + Math.round(n).toLocaleString('en-IN');

  const handlePayNow = async () => {
    setSaving(true);
    setAction('pay_now');
    const today = new Date().toISOString().split('T')[0];

    await base44.entities.Invoice.update(invoice.id, {
      status: 'paid',
      paid_date: today,
      payment_method_used: method,
      payment_reference: reference || '',
      notes: (invoice.notes ? invoice.notes + '\n' : '') +
        `Paid by client on ${today} via ${method}${reference ? ` (Ref: ${reference})` : ''}`,
    });

    // Audit log
    await base44.entities.AuditLog.create({
      actor_email: client?.email || '',
      actor_name: client?.full_name || '',
      actor_type: 'client',
      action: 'marked_invoice_paid',
      entity_type: 'Invoice',
      entity_id: invoice.id,
      details: `Invoice ${invoice.invoice_number} marked paid via ${method}${reference ? ` Ref: ${reference}` : ''}`,
    });

    setSaving(false);
    setStep('done');
    if (onRefresh) setTimeout(onRefresh, 500);
  };

  const handlePayLater = async () => {
    setSaving(true);
    setAction('pay_later');
    const today = new Date().toISOString().split('T')[0];

    await base44.entities.Invoice.update(invoice.id, {
      notes: (invoice.notes ? invoice.notes + '\n' : '') +
        `Client deferred payment on ${today} (method: ${method})`,
    });

    await base44.entities.AuditLog.create({
      actor_email: client?.email || '',
      actor_name: client?.full_name || '',
      actor_type: 'client',
      action: 'deferred_payment',
      entity_type: 'Invoice',
      entity_id: invoice.id,
      details: `Invoice ${invoice.invoice_number} payment deferred by client via ${method}`,
    });

    setSaving(false);
    if (onRefresh) onRefresh();
    onClose();
  };

  if (!invoice) return null;

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-background/85 backdrop-blur-md" onClick={onClose}>
      <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
        className="relative bg-background border border-border w-full max-w-lg max-h-[92vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
        <div className="absolute top-0 left-0 right-0 h-px bg-saffron" />

        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-border">
          <div>
            <p className="font-body text-xs tracking-widest uppercase text-saffron mb-0.5">Make Payment</p>
            <h3 className="font-display text-xl text-chalk font-light">{invoice.invoice_number}</h3>
            <p className="font-body text-xs text-chalk/40">{invoice.service}</p>
          </div>
          <button onClick={onClose} className="text-chalk/30 hover:text-chalk min-w-[36px] min-h-[36px] flex items-center justify-center">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Invoice Summary */}
        <div className="p-6 border-b border-border">
          <div className="grid grid-cols-3 gap-4 mb-4">
            <div>
              <p className="font-body text-[10px] uppercase tracking-widest text-chalk/30 mb-0.5">Subtotal</p>
              <p className="font-body text-sm text-chalk">{fmt(taxable)}</p>
            </div>
            <div>
              <p className="font-body text-[10px] uppercase tracking-widest text-chalk/30 mb-0.5">VAT {invoice.tax_rate || 13}%</p>
              <p className="font-body text-sm text-chalk">{fmt(vatAmt)}</p>
            </div>
            <div>
              <p className="font-body text-[10px] uppercase tracking-widest text-chalk/30 mb-0.5">Total Due</p>
              <p className="font-display text-lg text-saffron font-light">{fmt(total)}</p>
            </div>
          </div>
          {invoice.payment_due_date && (
            <div className="border border-amber-400/20 bg-amber-400/5 px-4 py-2.5 flex items-center gap-2">
              <Clock className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
              <p className="font-body text-xs text-amber-400">Payment due by <strong>{invoice.payment_due_date}</strong></p>
            </div>
          )}
        </div>

        <AnimatePresence mode="wait">
          {/* Step 1: Choose Method */}
          {step === 'method' && (
            <motion.div key="method" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="p-6">
              <p className="font-body text-xs tracking-widest uppercase text-chalk/35 mb-4">Select Payment Method</p>
              <div className="space-y-2 mb-6">
                {METHODS.map(m => {
                  const Icon = m.icon;
                  return (
                    <button key={m.id} type="button" onClick={() => setMethod(m.id)}
                      className={`w-full flex items-center gap-3 p-4 border transition-all text-left ${
                        method === m.id ? m.color + ' ring-1 ring-current' : 'border-basalt/30 text-chalk/50 hover:border-basalt/60'
                      }`}>
                      {m.emoji ? <span className="text-lg w-5 text-center">{m.emoji}</span>
                               : Icon ? <Icon className="w-5 h-5 flex-shrink-0" /> : null}
                      <div className="flex-1">
                        <p className="font-body text-sm">{m.label}</p>
                        <p className="font-body text-[10px] text-chalk/30 mt-0.5">{m.desc}</p>
                      </div>
                      {method === m.id && <Check className="w-4 h-4 flex-shrink-0" />}
                    </button>
                  );
                })}
              </div>

              {/* Bank details if bank_transfer */}
              {method === 'bank_transfer' && (
                <motion.div initial={{ opacity: 0, y: -6 }} animate={{ opacity: 1, y: 0 }} className="border border-blue-400/20 bg-blue-400/5 p-4 mb-6">
                  <p className="font-body text-xs tracking-widest uppercase text-blue-400/60 mb-3">Bank Transfer Details</p>
                  {[
                    ['Bank', BANK_DETAILS.bank],
                    ['Branch', BANK_DETAILS.branch],
                    ['Account Name', BANK_DETAILS.account_name],
                    ['Account No.', BANK_DETAILS.account_no],
                    ['SWIFT Code', BANK_DETAILS.swift],
                  ].map(([label, val]) => (
                    <div key={label} className="flex items-center justify-between py-1.5 border-b border-blue-400/10 last:border-0">
                      <span className="font-body text-xs text-chalk/35">{label}</span>
                      <div className="flex items-center gap-2">
                        <span className="font-body text-xs text-chalk font-mono">{val}</span>
                        <button onClick={() => copy(val, label)} className="text-chalk/30 hover:text-saffron">
                          {copied === label ? <Check className="w-3 h-3 text-saffron" /> : <Copy className="w-3 h-3" />}
                        </button>
                      </div>
                    </div>
                  ))}
                </motion.div>
              )}

              <div className="flex gap-3">
                <button onClick={() => setStep('confirm')} disabled={!method}
                  className="flex-1 font-body text-sm py-3 bg-saffron text-background font-medium tracking-wider uppercase hover:bg-saffron/90 disabled:opacity-40 transition-all min-h-[44px]">
                  Continue
                </button>
                <button onClick={onClose}
                  className="font-body text-xs px-5 py-3 border border-basalt/30 text-chalk/40 uppercase tracking-wider min-h-[44px]">
                  Cancel
                </button>
              </div>
            </motion.div>
          )}

          {/* Step 2: Confirm & Pay */}
          {step === 'confirm' && (
            <motion.div key="confirm" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -20 }} className="p-6 space-y-5">
              <div className="border border-saffron/20 bg-saffron/5 p-4">
                <p className="font-body text-[10px] uppercase tracking-widest text-chalk/30 mb-1">Paying via</p>
                <p className="font-body text-sm text-saffron capitalize">{method.replace('_', ' ')}</p>
                <p className="font-display text-2xl text-chalk font-light mt-1">{fmt(total)}</p>
              </div>

              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2">
                  Transaction Reference <span className="text-chalk/25">(optional)</span>
                </label>
                <input type="text" value={reference} onChange={e => setReference(e.target.value)}
                  placeholder="Enter bank ref, eSewa txn ID, etc."
                  className="w-full bg-transparent border-b border-basalt/30 py-2 font-body text-sm text-chalk placeholder:text-chalk/20 focus:border-saffron focus:outline-none" />
              </div>

              <div className="space-y-2">
                <button onClick={handlePayNow} disabled={saving}
                  className="w-full flex items-center justify-center gap-2 font-body text-sm py-3.5 bg-saffron text-background font-medium uppercase tracking-wider hover:bg-saffron/90 disabled:opacity-50 transition-all min-h-[44px]">
                  {saving && action === 'pay_now' ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                  {saving && action === 'pay_now' ? 'Marking as Paid...' : 'I Have Paid — Confirm'}
                </button>
                <button onClick={handlePayLater} disabled={saving}
                  className="w-full flex items-center justify-center gap-2 font-body text-sm py-3.5 border border-basalt/30 text-chalk/50 uppercase tracking-wider hover:text-chalk hover:border-basalt/60 disabled:opacity-50 transition-all min-h-[44px]">
                  {saving && action === 'pay_later' ? <Loader2 className="w-4 h-4 animate-spin" /> : <Clock className="w-4 h-4" />}
                  Pay Later
                </button>
              </div>

              <button onClick={() => setStep('method')} className="font-body text-xs text-chalk/30 hover:text-chalk transition-colors">← Change Method</button>
            </motion.div>
          )}

          {/* Step 3: Done */}
          {step === 'done' && (
            <motion.div key="done" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="p-8 text-center">
              <div className="w-14 h-14 border-2 border-emerald-400 flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-7 h-7 text-emerald-400" />
              </div>
              <h3 className="font-display text-2xl text-chalk font-light mb-2">Payment Confirmed</h3>
              <p className="font-body text-sm text-chalk/40 mb-1">Invoice <strong>{invoice.invoice_number}</strong> marked as Paid.</p>
              {reference && <p className="font-body text-xs text-chalk/30">Ref: {reference}</p>}
              <button onClick={onClose} className="mt-6 font-body text-xs px-6 py-2.5 border border-basalt/30 text-chalk/50 hover:border-saffron hover:text-saffron transition-all min-h-[44px]">
                Close
              </button>
            </motion.div>
          )}
        </AnimatePresence>

        <p className="font-body text-[10px] text-chalk/20 text-center px-6 pb-4 leading-relaxed">
          After bank transfer, send proof to info@mbista.com.np with your Client ID: {client?.client_id || ''}
        </p>
      </motion.div>
    </motion.div>
  );
}