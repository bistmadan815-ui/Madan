import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { base44 } from '@/api/base44Client';
import {
  Plus, X, Check, Loader2, MessageSquare, Paperclip, Clock,
  CheckCircle2, AlertCircle, ChevronRight, Send, Tag, Upload
} from 'lucide-react';

const PRIORITY_CONFIG = {
  low:    { label: 'Low',    color: 'text-emerald-400 border-emerald-400/30 bg-emerald-400/5' },
  medium: { label: 'Medium', color: 'text-amber-400 border-amber-400/30 bg-amber-400/5' },
  high:   { label: 'High',   color: 'text-red-400 border-red-400/30 bg-red-400/5' },
};

const STATUS_STEPS = ['pending', 'in_review', 'resolved'];
const STATUS_LABELS = { pending: 'Submitted', in_review: 'In Progress', resolved: 'Resolved', rejected: 'Rejected' };

function StatusTimeline({ status }) {
  if (status === 'rejected') {
    return (
      <div className="flex items-center gap-2 mt-2">
        <AlertCircle className="w-4 h-4 text-red-400" />
        <span className="font-body text-xs text-red-400">Request Rejected</span>
      </div>
    );
  }
  const currentIdx = STATUS_STEPS.indexOf(status);
  return (
    <div className="flex items-center gap-0 mt-3">
      {STATUS_STEPS.map((step, i) => {
        const done = i <= currentIdx;
        const active = i === currentIdx;
        return (
          <div key={step} className="flex items-center">
            <div className={`flex items-center gap-1.5 ${done ? 'text-saffron' : 'text-chalk/20'}`}>
              <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${active ? 'border-saffron bg-saffron/10' : done ? 'border-saffron bg-saffron' : 'border-basalt/30'}`}>
                {done && !active && <Check className="w-3 h-3 text-background" />}
                {active && <div className="w-2 h-2 rounded-full bg-saffron" />}
              </div>
              <span className="font-body text-[10px] tracking-widest uppercase">{STATUS_LABELS[step]}</span>
            </div>
            {i < STATUS_STEPS.length - 1 && (
              <div className={`w-8 h-px mx-1 ${i < currentIdx ? 'bg-saffron' : 'bg-basalt/20'}`} />
            )}
          </div>
        );
      })}
    </div>
  );
}

function TicketDetail({ ticket, client, onClose, onUpdated }) {
  const [comment, setComment] = useState('');
  const [sending, setSending] = useState(false);
  const bottomRef = useRef();

  const comments = ticket.comments || [];

  const handleSend = async (e) => {
    e.preventDefault();
    if (!comment.trim()) return;
    setSending(true);
    const newComment = { author: client.full_name, role: 'client', text: comment.trim(), ts: new Date().toISOString() };
    const updatedComments = [...comments, newComment];
    await base44.entities.ClientRequest.update(ticket.id, { comments: updatedComments });
    setSending(false);
    setComment('');
    onUpdated();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-background/80 backdrop-blur-md" onClick={onClose}>
      <motion.div initial={{ opacity: 0, y: 40 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 20 }}
        className="relative bg-background border border-border w-full sm:max-w-2xl h-full sm:h-auto sm:max-h-[85vh] flex flex-col" onClick={e => e.stopPropagation()}>
        <div className="absolute top-0 left-0 right-0 h-px bg-saffron" />

        {/* Header */}
        <div className="flex items-start justify-between p-6 border-b border-border flex-shrink-0">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1 flex-wrap">
              <span className={`font-body text-[10px] tracking-widest uppercase px-2 py-0.5 border ${PRIORITY_CONFIG[ticket.priority]?.color || PRIORITY_CONFIG.medium.color}`}>
                {ticket.priority || 'medium'}
              </span>
              <span className="font-body text-xs text-chalk/30">#{ticket.id?.slice(-6)}</span>
            </div>
            <p className="font-display text-xl text-chalk font-light">{ticket.subject || ticket.description?.slice(0, 60)}</p>
            <StatusTimeline status={ticket.status} />
          </div>
          <button onClick={onClose} className="text-chalk/30 hover:text-chalk ml-4 flex-shrink-0"><X className="w-5 h-5" /></button>
        </div>

        {/* Thread */}
        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* Original request */}
          <div className="flex gap-3">
            <div className="w-8 h-8 rounded-full bg-saffron/20 border border-saffron/40 flex items-center justify-center flex-shrink-0">
              <span className="font-body text-xs text-saffron">{client.full_name?.[0]}</span>
            </div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-body text-xs text-chalk/60">{client.full_name}</span>
                <span className="font-body text-[10px] text-chalk/25">{new Date(ticket.created_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}</span>
              </div>
              <div className="bg-saffron/5 border border-saffron/20 p-3">
                <p className="font-body text-sm text-chalk/80 leading-relaxed">{ticket.description}</p>
                {ticket.attachment_url && (
                  <a href={ticket.attachment_url} target="_blank" rel="noopener noreferrer"
                    className="flex items-center gap-1.5 mt-2 font-body text-xs text-saffron hover:underline">
                    <Paperclip className="w-3 h-3" /> {ticket.attachment_name || 'Attachment'}
                  </a>
                )}
              </div>
            </div>
          </div>

          {/* Comments */}
          {comments.map((c, i) => {
            const isStaff = c.role === 'staff' || c.role === 'admin';
            return (
              <motion.div key={i} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} className="flex gap-3">
                <div className={`w-8 h-8 rounded-full border flex items-center justify-center flex-shrink-0 ${isStaff ? 'bg-violet-500/10 border-violet-400/40' : 'bg-saffron/10 border-saffron/30'}`}>
                  <span className={`font-body text-xs ${isStaff ? 'text-violet-400' : 'text-saffron'}`}>{c.author?.[0]}</span>
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-body text-xs text-chalk/60">{c.author}</span>
                    {isStaff && <span className="font-body text-[10px] text-violet-400 border border-violet-400/30 px-1.5 py-0.5">Staff</span>}
                    <span className="font-body text-[10px] text-chalk/25">{new Date(c.ts).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}</span>
                  </div>
                  <div className={`p-3 border ${isStaff ? 'bg-violet-500/5 border-violet-400/20' : 'bg-basalt/5 border-basalt/20'}`}>
                    <p className="font-body text-sm text-chalk/80 leading-relaxed">{c.text}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
          <div ref={bottomRef} />
        </div>

        {/* Reply box — only if not resolved/rejected */}
        {ticket.status !== 'resolved' && ticket.status !== 'rejected' && (
          <div className="border-t border-border p-4 flex-shrink-0">
            <form onSubmit={handleSend} className="flex gap-3">
              <textarea rows={2} value={comment} onChange={e => setComment(e.target.value)}
                placeholder="Type your message..."
                className="flex-1 bg-transparent border border-basalt/30 px-3 py-2 font-body text-sm text-chalk placeholder:text-chalk/20 focus:border-saffron focus:outline-none resize-none" />
              <button type="submit" disabled={sending || !comment.trim()}
                className="flex items-center gap-2 font-body text-xs px-4 py-2 bg-saffron text-background uppercase tracking-wider hover:bg-saffron/90 disabled:opacity-40 transition-all self-end">
                {sending ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              </button>
            </form>
          </div>
        )}
      </motion.div>
    </div>
  );
}

export default function SupportTab({ client, onRefresh }) {
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [viewing, setViewing] = useState(null);
  const [uploadingFile, setUploadingFile] = useState(false);
  const [form, setForm] = useState({ subject: '', description: '', priority: 'medium', attachment_url: '', attachment_name: '' });
  const [saving, setSaving] = useState(false);
  const fileRef = useRef();

  const loadTickets = async () => {
    setLoading(true);
    const data = await base44.entities.ClientRequest.filter({ client_id: client.client_id, request_type: 'support' }, '-created_date', 50);
    setTickets(data);
    setLoading(false);
  };

  useEffect(() => { loadTickets(); }, []);

  const handleFileUpload = async (file) => {
    if (!file) return;
    setUploadingFile(true);
    const { file_url } = await base44.integrations.Core.UploadFile({ file });
    setForm(p => ({ ...p, attachment_url: file_url, attachment_name: file.name }));
    setUploadingFile(false);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.subject.trim() || !form.description.trim()) return;
    setSaving(true);
    const timeline = [{ status: 'pending', ts: new Date().toISOString(), note: 'Request submitted' }];
    await base44.entities.ClientRequest.create({
      client_id: client.client_id,
      client_name: client.full_name,
      client_email: client.email,
      request_type: 'support',
      subject: form.subject,
      description: form.description,
      priority: form.priority,
      attachment_url: form.attachment_url || '',
      attachment_name: form.attachment_name || '',
      status: 'pending',
      timeline,
      comments: [],
    });
    setSaving(false);
    setForm({ subject: '', description: '', priority: 'medium', attachment_url: '', attachment_name: '' });
    setShowForm(false);
    loadTickets();
    if (onRefresh) onRefresh();
  };

  const refreshViewing = async () => {
    await loadTickets();
    if (viewing) {
      const updated = await base44.entities.ClientRequest.filter({ client_id: client.client_id, request_type: 'support' }, '-created_date', 50);
      const fresh = updated.find(t => t.id === viewing.id);
      if (fresh) setViewing(fresh);
    }
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="font-display text-2xl text-chalk font-light">Support & Requests</h2>
          <p className="font-body text-xs text-chalk/35 mt-1">Submit queries, clarifications, or service requests to our team.</p>
        </div>
        <button onClick={() => setShowForm(v => !v)}
          className="flex items-center gap-2 font-body text-sm px-5 py-2.5 border border-saffron text-saffron hover:bg-saffron hover:text-background transition-all min-h-[44px]">
          <Plus className="w-4 h-4" /> New Request
        </button>
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -10 }}
            className="border border-border p-6 mb-8 relative">
            <div className="absolute top-0 left-0 right-0 h-px bg-saffron" />
            <div className="flex items-center justify-between mb-5">
              <p className="font-body text-xs tracking-widest uppercase text-saffron">Submit New Request</p>
              <button onClick={() => setShowForm(false)} className="text-chalk/30 hover:text-chalk"><X className="w-4 h-4" /></button>
            </div>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2">Subject <span className="text-saffron">*</span></label>
                <input type="text" value={form.subject} onChange={e => setForm(p => ({ ...p, subject: e.target.value }))}
                  placeholder="Brief description of your request"
                  className="w-full bg-transparent border-b border-basalt/30 py-3 font-body text-sm text-chalk placeholder:text-chalk/20 focus:border-saffron focus:outline-none" />
              </div>
              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2">Description <span className="text-saffron">*</span></label>
                <textarea rows={4} value={form.description} onChange={e => setForm(p => ({ ...p, description: e.target.value }))}
                  placeholder="Provide details about your request..."
                  className="w-full bg-transparent border-b border-basalt/30 py-2 font-body text-sm text-chalk placeholder:text-chalk/20 focus:border-saffron focus:outline-none resize-none" />
              </div>
              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2">Priority</label>
                <div className="flex gap-3">
                  {['low', 'medium', 'high'].map(p => (
                    <button key={p} type="button" onClick={() => setForm(prev => ({ ...prev, priority: p }))}
                      className={`font-body text-xs px-4 py-2 border capitalize transition-all ${form.priority === p ? PRIORITY_CONFIG[p].color + ' ring-1 ring-current' : 'border-basalt/30 text-chalk/40 hover:text-chalk'}`}>
                      {p}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block font-body text-xs tracking-widest uppercase text-chalk/35 mb-2">Attachment (Optional)</label>
                <div className="flex items-center gap-3">
                  <button type="button" onClick={() => fileRef.current?.click()}
                    disabled={uploadingFile}
                    className="flex items-center gap-2 font-body text-xs px-4 py-2 border border-basalt/30 text-chalk/50 hover:border-saffron hover:text-saffron transition-all min-h-[36px]">
                    {uploadingFile ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Upload className="w-3.5 h-3.5" />}
                    {uploadingFile ? 'Uploading...' : 'Attach File'}
                  </button>
                  {form.attachment_name && (
                    <div className="flex items-center gap-2">
                      <Paperclip className="w-3.5 h-3.5 text-saffron" />
                      <span className="font-body text-xs text-saffron/70">{form.attachment_name}</span>
                      <button type="button" onClick={() => setForm(p => ({ ...p, attachment_url: '', attachment_name: '' }))} className="text-chalk/30 hover:text-red-400">
                        <X className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>
                <input ref={fileRef} type="file" className="hidden" onChange={e => handleFileUpload(e.target.files[0])} />
              </div>
              <div className="flex gap-3 pt-2">
                <button type="submit" disabled={saving || !form.subject.trim() || !form.description.trim()}
                  className="flex items-center gap-2 font-body text-xs px-5 py-2.5 bg-saffron text-background uppercase tracking-wider hover:bg-saffron/90 disabled:opacity-40 transition-all min-h-[44px]">
                  {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                  {saving ? 'Submitting...' : 'Submit Request'}
                </button>
                <button type="button" onClick={() => setShowForm(false)}
                  className="font-body text-xs px-5 py-2.5 border border-basalt/30 text-chalk/40 uppercase tracking-wider min-h-[44px]">
                  Cancel
                </button>
              </div>
            </form>
          </motion.div>
        )}
      </AnimatePresence>

      {loading ? (
        <div className="flex justify-center py-12"><div className="w-5 h-5 border-2 border-saffron border-t-transparent rounded-full animate-spin" /></div>
      ) : tickets.length === 0 ? (
        <div className="text-center py-16 border border-dashed border-basalt/20">
          <MessageSquare className="w-10 h-10 text-chalk/15 mx-auto mb-3" />
          <p className="font-display text-xl text-chalk/20 font-light mb-1">No Requests Yet</p>
          <p className="font-body text-xs text-chalk/20">Submit a support request and our team will respond promptly.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {tickets.map((ticket, i) => {
            const pc = PRIORITY_CONFIG[ticket.priority] || PRIORITY_CONFIG.medium;
            const unread = (ticket.comments || []).some(c => c.role === 'staff' || c.role === 'admin');
            return (
              <motion.div key={ticket.id} initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}
                onClick={() => setViewing(ticket)} className="border border-border p-5 cursor-pointer hover:border-saffron/30 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1 flex-wrap">
                      <span className={`font-body text-[10px] tracking-widest uppercase px-2 py-0.5 border ${pc.color}`}>{pc.label}</span>
                      {ticket.status === 'resolved' && <span className="font-body text-[10px] tracking-widest uppercase px-2 py-0.5 border text-emerald-400 border-emerald-400/30 bg-emerald-400/5">Resolved</span>}
                      {ticket.status === 'in_review' && <span className="font-body text-[10px] tracking-widest uppercase px-2 py-0.5 border text-blue-400 border-blue-400/30 bg-blue-400/5">In Progress</span>}
                      {ticket.status === 'rejected' && <span className="font-body text-[10px] tracking-widest uppercase px-2 py-0.5 border text-red-400 border-red-400/30 bg-red-400/5">Rejected</span>}
                      {unread && ticket.status !== 'resolved' && <span className="font-body text-[10px] text-violet-400">● Response</span>}
                    </div>
                    <p className="font-body text-sm text-chalk truncate">{ticket.subject || ticket.description}</p>
                    <StatusTimeline status={ticket.status} />
                    <p className="font-body text-[10px] text-chalk/20 mt-2">
                      {new Date(ticket.created_date).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                      {ticket.comments?.length > 0 && ` · ${ticket.comments.length} message${ticket.comments.length > 1 ? 's' : ''}`}
                    </p>
                  </div>
                  <ChevronRight className="w-4 h-4 text-chalk/25 flex-shrink-0 mt-1" />
                </div>
              </motion.div>
            );
          })}
        </div>
      )}

      <AnimatePresence>
        {viewing && (
          <TicketDetail ticket={viewing} client={client} onClose={() => setViewing(null)} onUpdated={refreshViewing} />
        )}
      </AnimatePresence>
    </div>
  );
}